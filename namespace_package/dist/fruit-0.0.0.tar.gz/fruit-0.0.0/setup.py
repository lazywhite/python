from setuptools import setup

setup(
    name='fruit',
    packages=['fruit.apple', 'fruit.banana']
)
